MOTOR-STEUERUNG (Bluetooth LE) - Android-App fuer den Nano ESP32
================================================================

Die App verbindet sich per Bluetooth LE mit dem Board (main.py, Geraetename
"NanoMotor") und steuert beide Motoren mit Tasten und Schiebereglern.
Sie sendet genau die Befehle von main.py: F1 B1 S1 F2 B2 S2, S (alle stopp),
V1:50 / V2:80 (Geschwindigkeit in Prozent).

VORAUSSETZUNG AUF DEM BOARD
- main.py (BLE-Version, NICHT main_wifi.py) laeuft auf dem Nano ESP32.
- Im REPL steht "Bereit - suche am Handy nach: NanoMotor".

APK ERSTELLEN (auf dem PC, einmalig ca. 10-15 Minuten)
1. Android Studio installieren: https://developer.android.com/studio
2. ZIP entpacken. In Android Studio: File > Open > Ordner "MotorBLE" waehlen.
3. Warten, bis "Gradle Sync" fertig ist (laedt Gradle und ggf. das Android-SDK 35
   nach; Internet noetig). Fehlt ein SDK-Paket, auf den "Install"-Link klicken.
   Schlaegt Studio ein Upgrade des Android Gradle Plugins vor: annehmen.
4. Menue: Build > Build Bundle(s) / APK(s) > Build APK(s)
5. Nach dem Bau auf "locate" klicken:
   app/build/outputs/apk/debug/app-debug.apk

AUF DEM HANDY INSTALLIEREN
- app-debug.apk aufs Handy kopieren, antippen, "Installation aus dieser Quelle
  zulassen" bestaetigen.
- Oder: Handy per USB anschliessen (USB-Debugging an) und in Android Studio auf
  den gruenen Run-Pfeil klicken.

BENUTZEN
1. Bluetooth am Handy einschalten. Android 11 oder aelter: auch den Standort
   einschalten (Android verlangt das fuer die Bluetooth-Suche).
2. App starten, "Mit NanoMotor verbinden" tippen, Berechtigung erlauben.
3. Nach dem Verbinden werden Tasten und Regler freigeschaltet.
   - "Nur fahren, solange die Taste gedrueckt ist" = Totmann-Modus.
   - "ALLE STOPP" haelt beide Motoren sofort an.
   - Geht die App in den Hintergrund oder reisst die Verbindung ab,
     stoppen die Motoren.
Nicht noetig: Koppeln in den Bluetooth-Einstellungen des Handys.

PROBLEME
- "NanoMotor nicht gefunden": laeuft main.py? Ist das Board schon mit einem
  anderen Geraet verbunden (z.B. Thonny/Arduino Lab nicht, aber eine andere
  BLE-App)? Dann dort trennen.
- "Nordic-UART-Dienst nicht gefunden": das Board laeuft nicht mit der BLE-Version.
