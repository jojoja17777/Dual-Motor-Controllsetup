package de.nanomotor.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.SeekBar;
import android.widget.TextView;

import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.UUID;

/**
 * Steuert den Nano ESP32 (main.py, BLE / Nordic UART Service) mit Tasten und Schiebereglern.
 * Befehle: F1 B1 S1 F2 B2 S2, F B S (beide), V1:50 V2:80 (Geschwindigkeit in Prozent).
 */
@SuppressLint("MissingPermission")
public class MainActivity extends Activity {

    private static final String DEVICE_NAME = "NanoMotor";
    private static final UUID NUS_SERVICE = UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e");
    private static final UUID NUS_RX = UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e"); // Handy schreibt hierhin
    private static final UUID NUS_TX = UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e"); // Board meldet hierueber
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private static final int REQ_PERMISSIONS = 1;
    private static final int COLOR_ON = 0xFF2563EB;
    private static final int COLOR_OFF = 0xFFE5E7EB;

    private static final int[] BACK = {R.id.back1, R.id.back2};
    private static final int[] STOP = {R.id.stop1, R.id.stop2};
    private static final int[] FWD = {R.id.fwd1, R.id.fwd2};
    private static final int[] SEEK = {R.id.seek1, R.id.seek2};
    private static final int[] SPEED = {R.id.speed1, R.id.speed2};
    private static final int[] STATE = {R.id.state1, R.id.state2};

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayDeque<String> queue = new ArrayDeque<>();
    private final int[] dirState = new int[2];       // -1 zurueck, 0 stopp, 1 vor

    private final Button[] backBtn = new Button[2];
    private final Button[] stopBtn = new Button[2];
    private final Button[] fwdBtn = new Button[2];
    private final SeekBar[] seek = new SeekBar[2];
    private final TextView[] speedTv = new TextView[2];
    private final TextView[] stateTv = new TextView[2];

    private Button connectBtn;
    private Button allStopBtn;
    private TextView statusTv;
    private TextView logTv;
    private CheckBox holdCb;

    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic rxChar;
    private boolean scanning = false;
    private boolean ready = false;
    private boolean writing = false;
    private int failCount = 0;

    // Falls kein Schreib-Callback kommt, Sperre nach kurzer Zeit loesen
    private final Runnable unlock = new Runnable() {
        @Override
        public void run() {
            writing = false;
            pump();
        }
    };

    private final Runnable scanTimeout = new Runnable() {
        @Override
        public void run() {
            if (scanning) {
                stopScan();
                setStatus("NanoMotor nicht gefunden. Läuft main.py auf dem Board? "
                        + "(Android 11 oder älter: Standort einschalten)");
                resetUi();
            }
        }
    };

    // ---------------------------------------------------------------- Lebenszyklus

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);

        statusTv = findViewById(R.id.status);
        logTv = findViewById(R.id.log);
        connectBtn = findViewById(R.id.connect);
        allStopBtn = findViewById(R.id.allstop);
        holdCb = findViewById(R.id.hold);

        for (int i = 0; i < 2; i++) {
            final int m = i + 1;
            backBtn[i] = findViewById(BACK[i]);
            stopBtn[i] = findViewById(STOP[i]);
            fwdBtn[i] = findViewById(FWD[i]);
            seek[i] = findViewById(SEEK[i]);
            speedTv[i] = findViewById(SPEED[i]);
            stateTv[i] = findViewById(STATE[i]);
            wireDirection(backBtn[i], m, -1);
            wireDirection(stopBtn[i], m, 0);
            wireDirection(fwdBtn[i], m, 1);
            wireSeek(i);
        }

        allStopBtn.setOnClickListener(v -> allStop());
        connectBtn.setOnClickListener(v -> onConnectClicked());

        BluetoothManager manager = getSystemService(BluetoothManager.class);
        adapter = manager != null ? manager.getAdapter() : null;

        setUiEnabled(false);
        render();
    }

    @Override
    protected void onPause() {
        // Sicherheit: App im Hintergrund -> Motoren anhalten
        if (ready) {
            allStop();
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        stopScan();
        if (gatt != null) {
            gatt.disconnect();
            gatt.close();
            gatt = null;
        }
        super.onDestroy();
    }

    // ---------------------------------------------------------------- Bedienung

    private void wireDirection(Button b, final int m, final int d) {
        b.setOnTouchListener((v, ev) -> {
            if (!holdCb.isChecked() || d == 0) {
                return false;       // normaler Klick
            }
            int action = ev.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN) {
                dir(m, d);
            } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                if (dirState[m - 1] == d) {
                    dir(m, 0);
                }
            }
            return true;
        });
        b.setOnClickListener(v -> {
            if (!holdCb.isChecked() || d == 0) {
                dir(m, d);
            }
        });
    }

    private void wireSeek(final int i) {
        final int m = i + 1;
        seek[i].setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            private long last = 0;

            @Override
            public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                speedTv[i].setText("Geschwindigkeit: " + progress + " %");
                long now = SystemClock.uptimeMillis();
                if (fromUser && now - last > 100) {
                    last = now;
                    send("V" + m + ":" + progress);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
                send("V" + m + ":" + sb.getProgress());
            }
        });
    }

    private void dir(int m, int d) {
        dirState[m - 1] = d;
        send((d > 0 ? "F" : d < 0 ? "B" : "S") + m);
        render();
    }

    private void allStop() {
        dirState[0] = 0;
        dirState[1] = 0;
        send("S");
        render();
    }

    private void render() {
        String[] names = {"Rückwärts", "Stopp", "Vorwärts"};
        for (int i = 0; i < 2; i++) {
            stateTv[i].setText(names[dirState[i] + 1]);
            paint(backBtn[i], dirState[i] == -1);
            paint(stopBtn[i], dirState[i] == 0);
            paint(fwdBtn[i], dirState[i] == 1);
        }
    }

    private void paint(Button b, boolean on) {
        b.setBackgroundColor(on ? COLOR_ON : COLOR_OFF);
        b.setTextColor(on ? 0xFFFFFFFF : 0xFF1B1F24);
    }

    private void setUiEnabled(boolean on) {
        float alpha = on ? 1f : 0.5f;
        for (int i = 0; i < 2; i++) {
            backBtn[i].setEnabled(on);
            stopBtn[i].setEnabled(on);
            fwdBtn[i].setEnabled(on);
            seek[i].setEnabled(on);
            backBtn[i].setAlpha(alpha);
            stopBtn[i].setAlpha(alpha);
            fwdBtn[i].setAlpha(alpha);
            seek[i].setAlpha(alpha);
        }
        allStopBtn.setEnabled(on);
        allStopBtn.setAlpha(alpha);
    }

    private void setStatus(String text) {
        statusTv.setText(text);
    }

    private void log(String text) {
        String s = text.trim() + "\n" + logTv.getText();
        logTv.setText(s.length() > 300 ? s.substring(0, 300) : s);
    }

    private void resetUi() {
        connectBtn.setText("Mit NanoMotor verbinden");
        setUiEnabled(false);
    }

    // ---------------------------------------------------------------- Verbinden

    private void onConnectClicked() {
        if (scanning) {
            stopScan();
            setStatus("Abgebrochen");
            resetUi();
            return;
        }
        if (gatt != null) {
            if (ready) {
                allStop();
            }
            gatt.disconnect();
            return;
        }
        if (adapter == null || !adapter.isEnabled()) {
            setStatus("Bitte Bluetooth einschalten.");
            return;
        }
        if (!hasPermissions()) {
            requestPermissions(neededPermissions(), REQ_PERMISSIONS);
            return;
        }
        startScan();
    }

    private String[] neededPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT};
        }
        return new String[]{Manifest.permission.ACCESS_FINE_LOCATION};
    }

    private boolean hasPermissions() {
        for (String p : neededPermissions()) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code != REQ_PERMISSIONS) {
            return;
        }
        boolean ok = results.length > 0;
        for (int r : results) {
            if (r != PackageManager.PERMISSION_GRANTED) {
                ok = false;
            }
        }
        if (ok) {
            startScan();
        } else {
            setStatus("Erlaubnis verweigert. Bluetooth-/Standort-Berechtigung wird benötigt.");
        }
    }

    private void startScan() {
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) {
            setStatus("Bluetooth-Scanner nicht verfügbar.");
            return;
        }
        scanning = true;
        setStatus("Suche nach " + DEVICE_NAME + " …");
        connectBtn.setText("Abbrechen");
        ScanSettings settings = new ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                .build();
        scanner.startScan(null, settings, scanCallback);
        handler.postDelayed(scanTimeout, 15000);
    }

    private void stopScan() {
        if (!scanning) {
            return;
        }
        scanning = false;
        handler.removeCallbacks(scanTimeout);
        try {
            scanner.stopScan(scanCallback);
        } catch (Exception ignored) {
            // Bluetooth evtl. gerade ausgeschaltet
        }
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            if (!scanning) {
                return;
            }
            ScanRecord record = result.getScanRecord();
            String name = record != null ? record.getDeviceName() : null;
            if (name != null && name.startsWith(DEVICE_NAME)) {
                stopScan();
                setStatus("Verbinde …");
                gatt = result.getDevice().connectGatt(
                        MainActivity.this, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
            }
        }

        @Override
        public void onScanFailed(int errorCode) {
            stopScan();
            setStatus("Scan fehlgeschlagen (Fehler " + errorCode + ")");
            resetUi();
        }
    };

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                g.discoverServices();
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                g.close();
                runOnUiThread(() -> onDisconnected());
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt g, int status) {
            BluetoothGattService service = g.getService(NUS_SERVICE);
            BluetoothGattCharacteristic rx = service != null ? service.getCharacteristic(NUS_RX) : null;
            BluetoothGattCharacteristic tx = service != null ? service.getCharacteristic(NUS_TX) : null;
            if (status != BluetoothGatt.GATT_SUCCESS || rx == null || tx == null) {
                runOnUiThread(() -> setStatus("Nordic-UART-Dienst nicht gefunden. Läuft main.py (BLE-Version)?"));
                g.disconnect();
                return;
            }
            rxChar = rx;
            g.setCharacteristicNotification(tx, true);
            BluetoothGattDescriptor cccd = tx.getDescriptor(CCCD);
            if (cccd != null) {
                cccd.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                g.writeDescriptor(cccd);
            } else {
                runOnUiThread(() -> onReady());
            }
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor d, int status) {
            runOnUiThread(() -> onReady());
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt g, BluetoothGattCharacteristic c, int status) {
            runOnUiThread(() -> {
                handler.removeCallbacks(unlock);
                writing = false;
                pump();
            });
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) {
            byte[] value = c.getValue();
            if (value != null) {
                final String text = new String(value, StandardCharsets.UTF_8);
                runOnUiThread(() -> log(text));
            }
        }
    };

    private void onReady() {
        if (ready) {
            return;
        }
        ready = true;
        failCount = 0;
        dirState[0] = 0;
        dirState[1] = 0;
        setStatus("Verbunden mit " + DEVICE_NAME);
        connectBtn.setText("Trennen");
        setUiEnabled(true);
        render();
        // Geschwindigkeiten der Regler an das Board uebertragen
        send("V1:" + seek[0].getProgress());
        send("V2:" + seek[1].getProgress());
    }

    private void onDisconnected() {
        boolean wasReady = ready;
        ready = false;
        gatt = null;
        rxChar = null;
        queue.clear();
        writing = false;
        handler.removeCallbacks(unlock);
        dirState[0] = 0;
        dirState[1] = 0;
        render();
        resetUi();
        setStatus(wasReady ? "Verbindung getrennt (Motoren gestoppt)" : "Verbindung fehlgeschlagen. Bitte erneut versuchen.");
    }

    // ---------------------------------------------------------------- Senden

    private void send(String command) {
        if (!ready) {
            return;
        }
        queue.add(command);
        pump();
    }

    /** Schreibt immer nur einen Befehl gleichzeitig (Android erlaubt nur eine GATT-Operation). */
    private void pump() {
        if (writing || gatt == null || rxChar == null || queue.isEmpty()) {
            return;
        }
        String command = queue.poll();
        rxChar.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
        rxChar.setValue(command.getBytes(StandardCharsets.UTF_8));
        boolean started = gatt.writeCharacteristic(rxChar);
        if (started) {
            failCount = 0;
            writing = true;
            handler.removeCallbacks(unlock);
            handler.postDelayed(unlock, 250);
        } else if (++failCount < 20) {
            queue.addFirst(command);
            handler.removeCallbacks(unlock);
            handler.postDelayed(unlock, 30);
            writing = true;
        } else {
            queue.clear();
            failCount = 0;
        }
    }
}
